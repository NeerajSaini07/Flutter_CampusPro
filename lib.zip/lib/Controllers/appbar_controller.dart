import 'package:get/get.dart';

class AppbarController extends GetxController {
  var appBarName = ''.obs;
}
