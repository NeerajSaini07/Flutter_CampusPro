import 'package:flutter/cupertino.dart';

class HelpSupportPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      child: Center(
        child: Text("Help and Support"),
      ),
    );
  }
}
