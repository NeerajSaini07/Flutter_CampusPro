

// class stylesheet extends StatelessWidget{
//   const stylesheet({super.key, fontsize, color, fontweight});
  
//   @override
//   Widget build(BuildContext context) {
//     // TODO: implement build
//     return  TextStyle();
//   }

// }