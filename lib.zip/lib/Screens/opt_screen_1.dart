import 'package:campuspro/Utilities/colors.dart';
import 'package:flutter/material.dart';

class OTPScreen1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      backgroundColor: AppColors.loginscafoldcoolr,
      appBar: AppBar(),
    );
  }
}
