import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

Widget companylog() {
  return Center(
    child: Image.asset(
      "assets/images/companylogO2.png",
      fit: BoxFit.fitHeight,
      height: 62.h,
    ),
  );
}
