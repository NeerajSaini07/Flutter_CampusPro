import 'package:flutter/material.dart';

Widget customWidth(double width) {
  return SizedBox(
    width: width,
  );
}
